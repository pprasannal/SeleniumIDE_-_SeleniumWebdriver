package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddImmigrationDetailsInInfoPageTest {
	@FindBy(xpath="//a[@id=\'menu_pim_viewMyDetails\']/b")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),\'Immigration\')]")
	WebElement immigrationpage;
	@FindBy(id="btnAdd")
	WebElement addetails;
	@FindBy(xpath="//label[contains(.,\'Passport\')]")
	WebElement addpassport;
	@FindBy(id="immigration_number")
	WebElement number;
	@FindBy(id="btnSave")
	WebElement savedeatils;
	@FindBy(xpath="//div[3]/div[2]/div")
	WebElement verifymsg;
	WebDriver driver;
	public AddImmigrationDetailsInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void settoimmigrationpage(String no) {
		infopage.click();
		immigrationpage.click();
		addetails.click();
		addpassport.click();
		number.sendKeys(no);
		savedeatils.click();
	}
	public String getverifymsg() {
		return verifymsg.getText();
	}
	public void addimmigrationdetails(String no) {
		this.settoimmigrationpage(no);
		this.getverifymsg();
	}
}
