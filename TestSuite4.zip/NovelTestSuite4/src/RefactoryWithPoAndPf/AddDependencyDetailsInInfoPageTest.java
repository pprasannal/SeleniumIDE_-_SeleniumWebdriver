package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddDependencyDetailsInInfoPageTest {
	@FindBy(xpath="//a[@id=\'menu_pim_viewMyDetails\']/b")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),\'Dependents\')]")
	WebElement dependencypage;
	@FindBy(id="btnAddDependent")
	WebElement adddependence;
	@FindBy(id="heading")
	WebElement checkpage;
	@FindBy(id="dependent_name")
	WebElement name;
	@FindBy(id="dependent_relationshipType")
	WebElement addrelationshiptype;
	@FindBy(xpath="//option[. = 'Other']")
	WebElement chooseone;
	@FindBy(id="dependent_relationship")
	WebElement nameofrelationship;
	@FindBy(id="dependent_dateOfBirth")
	WebElement dob;
	@FindBy(xpath="//a[contains(text(),\'2\')]")
	WebElement choosedate;
	@FindBy(id="btnSaveDependent")
	WebElement  savedetails;
	WebDriver driver;
	public AddDependencyDetailsInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void settogodependecypage() {
		infopage.click();
		dependencypage.click();
		adddependence.click();
	}
	public String getcheckpage() {
		return checkpage.getText();
	}
	public void setdetails(String Name,String type,String NameofRelationship,String DOB) {
		name.sendKeys(Name);
		addrelationshiptype.sendKeys(type);
		chooseone.click();
		nameofrelationship.sendKeys(NameofRelationship);
		dob.sendKeys(DOB);
		choosedate.click();
		savedetails.click();
	}
	public void adddepenedency() {
		this.settogodependecypage();
		this.getcheckpage();
	}
}
