package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToImmigrationPageInInfoPage {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),'Immigration')]")
	WebElement immgirationpage;
	@FindBy(xpath="//div[@id='immidrationList']/div/h1")
	WebElement checkpage;
	WebDriver driver;
	public GoToImmigrationPageInInfoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setimmgirationpage() {
		infopage.click();
		immgirationpage.click();
	}
	public String getimmgirationPage() {
		return checkpage.getText();
	}
	public void gotoimmgiration() {
		this.setimmgirationpage();
		this.getimmgirationPage();
	}
}
