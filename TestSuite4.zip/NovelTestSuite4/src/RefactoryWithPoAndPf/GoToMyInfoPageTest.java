package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToMyInfoPageTest {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//div[@id='pdMainContainer']/div/h1")
	WebElement checkInfopage;
	WebDriver driver;
	public GoToMyInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setinfopage() {
		infopage.click();
	}
	public String getIfoPage() {
		return checkInfopage.getText();
	}
	public void gotoinfopage() {
		this.setinfopage();
		this.getIfoPage();
	}
}
