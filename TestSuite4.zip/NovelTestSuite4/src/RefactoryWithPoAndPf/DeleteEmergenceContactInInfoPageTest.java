package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//before deleting data , we need to insert the manually in web site
public class DeleteEmergenceContactInInfoPageTest {
	@FindBy(id="menu_pim_viewMyDetails")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),'Emergency Contacts')]")
	WebElement contactpage;
	@FindBy(xpath="//h1[contains(.,'Assigned Emergency Contacts')]")
	WebElement checkcontactpage;
	@FindBy(xpath="//table[@id='emgcontact_list']/tbody/tr[1]/td/input")
	WebElement choosecontact;
	@FindBy(id="delContactsBtn")
	WebElement deletebutton;
	WebDriver driver;
	public DeleteEmergenceContactInInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void settogocontactpage() {
		infopage.click();
		contactpage.click();
	}
	public String getcontactpage() {
		return checkcontactpage.getText();
	}
	public void setdelete() {
		choosecontact.click();
		deletebutton.click();
	}
	public void deleteEmergencyContacts() {
		this.settogocontactpage();
		this.getcontactpage();
		this.setdelete();
	}
}
