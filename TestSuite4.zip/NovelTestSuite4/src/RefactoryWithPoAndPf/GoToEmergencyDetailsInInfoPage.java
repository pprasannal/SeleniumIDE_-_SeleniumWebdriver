package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToEmergencyDetailsInInfoPage {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//a[contains(@href, '/orangehrm/orangehrm-4.4/symfony/web/index.php/pim/viewEmergencyContacts/empNumber/1')]")
	WebElement emergencypage;
	@FindBy(xpath="//div[@id='content']/div/div[3]")
	WebElement checkemergencypage;
	WebDriver driver;
	public GoToEmergencyDetailsInInfoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setimmgirationpage() {
		infopage.click();
		emergencypage.click();
	}
	public String getimmgirationpage() {
		return checkemergencypage.getText();
	}
	public void gotoemergencydetails() {
		this.setimmgirationpage();
		this.getimmgirationpage();
	}
}
