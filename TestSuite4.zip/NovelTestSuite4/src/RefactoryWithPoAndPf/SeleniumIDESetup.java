package RefactoryWithPoAndPf;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class SeleniumIDESetup {
WebDriver driver = null;
	
	@BeforeMethod
	void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\pl790\\Downloads\\chromedriver_win32(8)\\chromedriver.exe");
		driver = new ChromeDriver();
		 driver.manage().window().setSize(new Dimension(1254, 662));
		//driver.manage().timeouts().implicitlyWait(200,TimeUnit.DAYS.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);
		driver.get("http://localhost/orangehrm/orangehrm-4.4/symfony/web/index.php/auth/login");
		
	}

	@AfterMethod
	void tearDown() throws Exception {
		driver.close();
	}
}
