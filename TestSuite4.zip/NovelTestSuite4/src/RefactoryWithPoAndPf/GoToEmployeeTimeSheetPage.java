package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToEmployeeTimeSheetPage {
	@FindBy(xpath="//a[@id='menu_time_viewTimeModule']/b")
	WebElement timepage;
	@FindBy(xpath="//div[@id='content']/div/div/h1")
	WebElement checktimepage;
	WebDriver driver;
	public GoToEmployeeTimeSheetPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void settotimepage() {
		timepage.click();
	}
	public String gettimepage() {
		return checktimepage.getText();
	}
	public void gotoemployee() {
		this.settotimepage();
		this.gettimepage();
	}
}

