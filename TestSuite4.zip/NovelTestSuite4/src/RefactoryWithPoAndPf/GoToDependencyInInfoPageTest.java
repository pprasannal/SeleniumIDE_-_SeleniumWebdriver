package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToDependencyInInfoPageTest {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//a[contains(@href, '/orangehrm/orangehrm-4.4/symfony/web/index.php/pim/viewDependents/empNumber/1')]")
	WebElement dependencypage;
	@FindBy(xpath="//h1[contains(.,'Assigned Dependents')]")
	WebElement checkdependencypage;
	WebDriver driver;
	public GoToDependencyInInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setdependencypage() {
		infopage.click();
		dependencypage.click();
	}
	public String getdependencypage() {
		return checkdependencypage.getText();
	}
	public void gotodependencydetails() {
		this.setdependencypage();
		this.getdependencypage();
	}
}
