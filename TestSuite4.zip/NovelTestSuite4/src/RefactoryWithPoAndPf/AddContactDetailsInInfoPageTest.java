package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddContactDetailsInInfoPageTest {
	@FindBy(xpath="//a[@id=\'menu_pim_viewMyDetails\']/b")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),\'Contact Details\')]")
	WebElement contactpage;
	@FindBy(xpath="//h1[contains(.,\'Contact Details\')]")
	WebElement checkpage;
	@FindBy(id="btnSave")
	WebElement editbutton;
	@FindBy(id="contact_street1")
	WebElement street1;
	@FindBy(id="contact_street2")
	WebElement street2;
	@FindBy(id="contact_city")
	WebElement cityname;
	@FindBy(id="contact_emp_hm_telephone")
	WebElement telephonenumber;
	@FindBy(id="contact_emp_mobile")
	WebElement mobilenumber;
	@FindBy(id="contact_emp_work_telephone")
	WebElement telephonenumber2;
	@FindBy(id="contact_emp_work_email")
	WebElement emailname;
	@FindBy(id="contact_emp_oth_email")
	WebElement otheremail;
	@FindBy(id="btnSave")
	WebElement savedetails;
	WebDriver driver;
	public AddContactDetailsInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setcontactpage() {
		infopage.click();
		contactpage.click();
	}
	public String getcheckpage() {
		return checkpage.getText();
	}
	public void setDetails(String street1Name,String street2Name, String cityName, String number1, String number2,String number3,String email,String email2) {
		editbutton.click();
		street1.sendKeys(street1Name);
		street2.sendKeys(street2Name);
		cityname.sendKeys(cityName);
		telephonenumber.sendKeys(number1);
		mobilenumber.sendKeys(number2);
		telephonenumber2.sendKeys(number3);
		emailname.sendKeys(email);
		otheremail.sendKeys(email2);
		savedetails.click();
	}
	public void addcontats() {
		this.setcontactpage();
		this.getcheckpage();
	}
}
