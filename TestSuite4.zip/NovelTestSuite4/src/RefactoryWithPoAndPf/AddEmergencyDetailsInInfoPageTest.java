package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddEmergencyDetailsInInfoPageTest {
	@FindBy(xpath="//a[@id='menu_pim_viewMyDetails']/b")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),\'Emergency Contacts\')]")
	WebElement emergency;
	@FindBy(id="btnAddContact")
	WebElement addcontact;
	@FindBy(id="emergencyContactHeading")
	WebElement checkpage;
	@FindBy(id="emgcontacts_name")
	WebElement contactname;
	@FindBy(id="emgcontacts_relationship")
	WebElement contactrelationship;
	@FindBy(id="emgcontacts_homePhone")
	WebElement homepage;
	@FindBy(id="emgcontacts_mobilePhone")
	WebElement mobilephone;
	@FindBy(id="emgcontacts_workPhone")
	WebElement workphone;
	@FindBy(id="btnSaveEContact")
	WebElement savedetails;
	WebDriver driver;
	public AddEmergencyDetailsInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setgotocontactpage() {
		infopage.click();
		emergency.click();
		addcontact.click();
	}
	public String getcheckapge() {
		return checkpage.getText();
	}
	public void setdetails(String name , String relationship, String number1,String number2,String number3 ) {
		contactname.sendKeys(name);
		contactrelationship.sendKeys(relationship);
		homepage.sendKeys(number1);
		mobilephone.sendKeys(number2);
		workphone.sendKeys(number3);
		savedetails.click();
	}
	public void addemergencydetails() {
		this.setgotocontactpage();
		this.getcheckapge();
	}
}
