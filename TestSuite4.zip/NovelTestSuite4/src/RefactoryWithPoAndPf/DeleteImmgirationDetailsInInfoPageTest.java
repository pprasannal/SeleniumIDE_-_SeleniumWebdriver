package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//before deleting data , we need to insert the manually in web site
public class DeleteImmgirationDetailsInInfoPageTest {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),'Immigration')]")
	WebElement clickimmgiration;
	@FindBy(xpath="//div[@id='immidrationList']/div/h1")
	WebElement checimmgirationpage;
	@FindBy(name="chkImmigration[]")
	WebElement selectone;
	@FindBy(id="btnDelete")
	WebElement deletebutton;
	@FindBy(xpath="//div[3]/div[2]/div")
	WebElement verifymsg;
	WebDriver driver;
	public DeleteImmgirationDetailsInInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void gotoimmgirationpage() {
		infopage.click();
		clickimmgiration.click();
	}
	public void deleteoperation() {
		selectone.click();
		deletebutton.click();
	}
	public String ckeckimmgpage() {
		return checimmgirationpage.getText();
	}
	public String verifyMsg() {
		return verifymsg.getText();
	}
	public void deleteimmgiratdetails() {
		this.gotoimmgirationpage();
		this.ckeckimmgpage();
		this.deleteoperation();
		this.verifyMsg();
	}
}
