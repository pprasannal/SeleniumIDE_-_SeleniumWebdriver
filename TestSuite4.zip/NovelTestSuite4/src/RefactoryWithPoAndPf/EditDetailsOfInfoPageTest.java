package RefactoryWithPoAndPf;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EditDetailsOfInfoPageTest {
	WebDriver driver;
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//div[@id='pdMainContainer']/div/h1")
	WebElement checkinfopage;
	@FindBy(id="btnSave")
	WebElement clickedit;
	@FindBy(id="personal_txtEmpFirstName")
	WebElement firstname;
	@FindBy(id="personal_txtEmpMiddleName")
	WebElement middlename;
	@FindBy(id="personal_txtEmpLastName")
	WebElement lastname;
	@FindBy(id="personal_txtEmployeeId")
	WebElement newid;
	@FindBy(id="personal_txtOtherID")
	WebElement oldid;
	@FindBy(id="personal_txtLicenNo")
	WebElement licenseno;
	@FindBy(id="personal_txtLicExpDate")
	WebElement expdate;
	@FindBy(xpath="//a[contains(text(),\'2\')]")
	WebElement slectiondate;
	@FindBy(id="personal_cmbMarital")
	WebElement martial;
	@FindBy(xpath="//option[. = 'Married']")
	WebElement  optionslectionmartial;
	@FindBy(id="personal_cmbNation")
	WebElement nation;
	@FindBy(xpath="//option[. = 'Italian']")
	WebElement choosenation;
	@FindBy(id="personal_DOB")
	WebElement dob;
	@FindBy(xpath="//a[contains(text(),\'15\')]")
	WebElement selectdate;
	@FindBy(id="btnSave")
	WebElement savebutton;
	public EditDetailsOfInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setinfopage() {
		infopage.click();
	}
	public String checkInfopage() {
		return checkinfopage.getText();
	}
	public void setPersonalDetails(String firstName, String middleName, String lastName ,String newId,String oldId,String licenseNo, String expDate, String Martial,String Nation, String DOB ) {
		this.setinfopage();
		this.checkInfopage();
		clickedit.click();
		firstname.sendKeys(firstName);
		middlename.sendKeys(middleName);
		lastname.sendKeys(lastName);
		newid.sendKeys(newId);
		oldid.sendKeys(oldId);
		licenseno.sendKeys(licenseNo);
		expdate.click();
		expdate.sendKeys(expDate);
		slectiondate.click();
		 WebElement dropdown = driver.findElement(By.id("personal_cmbMarital"));
	      dropdown.findElement(By.xpath("//option[. = 'Married']")).click();
		martial.sendKeys(Martial);
		optionslectionmartial.click();
		nation.sendKeys(Nation);
		choosenation.click();
		dob.click();
		dob.sendKeys(DOB);
		selectdate.click();
		savebutton.click();
	}
	
}
