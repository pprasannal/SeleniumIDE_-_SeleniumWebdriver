package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddWorkExperienceDetailsInInfoPageTest {
	@FindBy(xpath="//a[@id=\'menu_pim_viewMyDetails\']/b")
	WebElement infopage;
	@FindBy(xpath="//div[3]/div/div/ul/li[9]/a")
	WebElement qualificationpage;
	@FindBy(id="addWorkExperience")
	WebElement addwork;
	@FindBy(id="headChangeWorkExperience")
	WebElement checkaddworkpage;
	@FindBy(id="experience_employer")
	WebElement companyname;
	@FindBy(id="experience_jobtitle")
	WebElement jobEcperience;
	@FindBy(id="experience_from_date")
	WebElement addfromdate;
	@FindBy(xpath="//a[contains(text(),\'2\')]")
	WebElement choosedate;
	@FindBy(id="experience_to_date")
	WebElement addtillexperiencedate;
	@FindBy(xpath="//a[contains(text(),\'2\')]")
	WebElement choosemonth;
	@FindBy(id="btnWorkExpSave")
	WebElement savedetails;
	WebDriver driver;
	public AddWorkExperienceDetailsInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void settogoworkexperiencepage() {
		infopage.click();
		qualificationpage.click();
		addwork.click();
	}
	public String getcheckexperiencepage() {
		return checkaddworkpage.getText();
	}
	public void setdetails(String name, String jobtitle,String fromdate,String todate) {
		companyname.sendKeys(name);
		jobEcperience.sendKeys(jobtitle);
		addfromdate.sendKeys(fromdate);
		choosedate.click();
		addtillexperiencedate.sendKeys(todate);
		choosemonth.click();
		savedetails.click();
	}
	public void addWorkexperience() {
		this.settogoworkexperiencepage();
		this.getcheckexperiencepage();
	}
}
