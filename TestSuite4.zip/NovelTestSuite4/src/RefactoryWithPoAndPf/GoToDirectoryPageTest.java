package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToDirectoryPageTest {
	@FindBy(xpath="//a[@id='menu_directory_viewDirectory']/b")
	WebElement directorypage;
	@FindBy(id="content")
	WebElement checkPage;
	WebDriver  driver;
	public GoToDirectoryPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setdirectorypage() {
		directorypage.click();
	}
	public String getpagechecked() {
		return checkPage.getText();
	}
	public void gotoDirectorypage() {
		this.setdirectorypage();
		this.getpagechecked();
	}
}
