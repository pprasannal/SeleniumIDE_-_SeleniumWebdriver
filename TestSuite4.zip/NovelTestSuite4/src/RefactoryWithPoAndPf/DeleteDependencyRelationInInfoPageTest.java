package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//before deleting data , we need to insert the manually in web site
public class DeleteDependencyRelationInInfoPageTest {
	@FindBy(xpath="//a[@id=\'menu_pim_viewMyDetails\']/b")
	WebElement infopage;
	@FindBy(xpath="//a[contains(text(),\'Dependents\')]")
	WebElement dependencypage;
	@FindBy(xpath="//h1[contains(.,\'Assigned Dependents\')]")
	WebElement checkdependencypage;
	@FindBy(xpath="(//input[@name=\'chkdependentdel[]\'])[1]")
	WebElement chooseoneoption;
	@FindBy(id="delDependentBtn")
	WebElement deletebutton;
	@FindBy(xpath="//div[3]/div[2]/div")
	WebElement verifymsg;
	WebDriver driver;
	public DeleteDependencyRelationInInfoPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setgodependencypage() {
		infopage.click();
		dependencypage.click();
	}
	public String getpageChecked() {
		return checkdependencypage.getText();
	}
	public void setoptiontodelete() {
		chooseoneoption.click();
		deletebutton.click();
	}
	public String getmsgChecked() {
		return verifymsg.getText();
	}
	public void deleteDependencypage() {
		this.setgodependencypage();
		this.getpageChecked();
		this.setoptiontodelete();
		this.getmsgChecked();
	}
}
