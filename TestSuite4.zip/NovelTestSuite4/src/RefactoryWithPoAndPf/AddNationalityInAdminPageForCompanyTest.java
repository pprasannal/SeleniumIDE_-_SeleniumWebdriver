package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddNationalityInAdminPageForCompanyTest {
	@FindBy(xpath="//a[@id=\'menu_admin_viewAdminModule\']/b")
	WebElement adminpage;
	@FindBy(id="menu_admin_nationality")
	WebElement nationpage;
	@FindBy(id="btnAdd")
	WebElement addnation;
	@FindBy(id="nationality_name")
	WebElement addnationname;
	@FindBy(xpath="//form[@id=\'frmNationality\']/fieldset/ol/li/span")
	WebElement spanmsg;
	@FindBy(id="btnSave")
	WebElement savebutton;
	@FindBy(id="nationality_name")
	WebElement renationname;
	@FindBy(id="btnSave")
	WebElement resavebutton;
	@FindBy(xpath="//form[@id=\'frmList_ohrmListComponent\']/div[2]")
	WebElement checknation;
	WebDriver driver;
	public AddNationalityInAdminPageForCompanyTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setnationpage(String name1) {
		adminpage.click();
		nationpage.click();
		addnation.click();
		addnationname.sendKeys(name1);
	}
	public String getcheckspanmsg() {
		return spanmsg.getText();
	}
	public void setnationnameagain(String name2) {
		savebutton.click();
		renationname.sendKeys(name2);
		resavebutton.click();
	}
	public String getlooknation() {
		return checknation.getText();
	}
}
