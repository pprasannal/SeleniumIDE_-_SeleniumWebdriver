package RefactoryWithPoAndPf;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestScript extends SeleniumIDESetup {
	LoginPage lpage;
	AddImmigrationDetailsInInfoPageTest addimmigration;
	GoToRecruitmentPage recuritmentpage;
	GoToQualificationPage qualificationpage;
	GoToMyInfoPageTest infopage;
	GoToImmigrationPageInInfoPage immgirationpage;
	GoToEmployeeTimeSheetPage timesheetpage;
	GoToEmergencyDetailsInInfoPage emergencypage;
	GoToDirectoryPageTest gotodirectorypage; 
	GoToDependencyInInfoPageTest dependencypage;
	GoToContactDetailsInInfoPageTest contactpage;
	EditDetailsOfInfoPageTest editdetails;
	DeleteImmgirationDetailsInInfoPageTest deletedata;
	DeleteEmergenceContactInInfoPageTest deletecontact;
	DeleteDependencyRelationInInfoPageTest deletedependency;
	AddWorkExperienceDetailsInInfoPageTest addworkexperiencepage;
	AddPostInBuzzPageTest addpost;
	AddNationalityInAdminPageForCompanyTest addnation;
	AddEmergencyDetailsInInfoPageTest addemergency;
	AddDependencyDetailsInInfoPageTest adddependency;
	AddContactDetailsInInfoPageTest addcontacts;
	AddCandidaeDetailsInRecruitmentPageTest addcandidatedetails;
	
	@Test(priority=7)
	public void addimmgirationininfo() {
		//before deleting data , we need to insert the manually in web site
		lpage =new LoginPage(driver);
		addimmigration = new AddImmigrationDetailsInInfoPageTest(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addimmigration.addimmigrationdetails("343424224");
		Assert.assertTrue(addimmigration.getverifymsg().contains("Successfully Saved"));
	}
	@Test(priority=20)
	public void  gotoRecuritementPageAferLogin() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		recuritmentpage = new GoToRecruitmentPage(driver);
		recuritmentpage.gotorecuritementpage();
	}
	@Test(priority=19)
	public void gotoqualificationpage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		qualificationpage = new GoToQualificationPage(driver);
		qualificationpage.gotoQualificationPage("License");
		Assert.assertTrue(qualificationpage.getqualificationChecked().contains("Work Experience"));
		Assert.assertEquals(qualificationpage.getEducationchecked(),"Education");
		Assert.assertFalse(qualificationpage.getLanguage().contains("lang"));
	} 
	@Test(priority=18)
	public void gotoInfoPage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		infopage = new GoToMyInfoPageTest(driver);
		infopage.gotoinfopage();
		Assert.assertEquals(infopage.getIfoPage(),"Personal Details" );
	}
	@Test(priority=17)
	public void gotoImmgirationPage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		immgirationpage = new GoToImmigrationPageInInfoPage(driver);
		immgirationpage.gotoimmgiration();
		Assert.assertEquals(immgirationpage.getimmgirationPage(),"Assigned Immigration Records" );
	}
	@Test(priority=16)
	public void gototimesheetPage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		timesheetpage = new GoToEmployeeTimeSheetPage(driver);
		timesheetpage.gotoemployee();
		Assert.assertEquals(timesheetpage.gettimepage(),"Select Employee" );
	}
	@Test(priority=15)
	public void gotoimmgirationPage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		emergencypage = new GoToEmergencyDetailsInInfoPage(driver);
		emergencypage.gotoemergencydetails();
		Assert.assertTrue(emergencypage.getimmgirationpage().contains("Assigned Emergency Contacts"));
	}
	@Test(priority=14)
	public void gotodirectorypage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		gotodirectorypage =new GoToDirectoryPageTest(driver);
		gotodirectorypage.gotoDirectorypage();
		Assert.assertTrue(gotodirectorypage.getpagechecked().contains("Search Directory"));
	}
	@Test(priority=13)
	public void gotodependencypage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		dependencypage = new GoToDependencyInInfoPageTest(driver);
		dependencypage.gotodependencydetails();
		Assert.assertTrue(dependencypage.getdependencypage().contains("Assigned Dependents"));
	}
	@Test(priority=12)
	public void gotocontactpage() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		contactpage =new GoToContactDetailsInInfoPageTest(driver);
		contactpage.gotocontactdetails();
		Assert.assertTrue(contactpage.getcontactpage().contains("Contact Details"));
	}
	@Test(priority=11)
	public void editdetailsofinfopage() {
		lpage =new LoginPage(driver);
		editdetails = new EditDetailsOfInfoPageTest(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		editdetails.setPersonalDetails("thomas", "kandle", "lucky", "0002", "0001", "23713819837645", "2022-12-2", "Married","Italian", "1999-5-15");
		Assert.assertEquals(editdetails.checkInfopage(),"Personal Details");
	}
	@Test(priority=10)
	//before deleting data , we need to insert the manually in web site
	public void deleteimmgirationdetailsininfopage() {
		lpage =new LoginPage(driver);
		deletedata = new DeleteImmgirationDetailsInInfoPageTest(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		deletedata.deleteimmgiratdetails();
		Assert.assertEquals(deletedata.ckeckimmgpage(),"Assigned Immigration Records");
		Assert.assertTrue(deletedata.verifyMsg().contains("Successfully Deleted"));
	}
	@Test(priority=9)
	//before deleting data , we need to insert the manually in web site
	public void deleteemergencyContacts() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		deletecontact = new DeleteEmergenceContactInInfoPageTest(driver);
		deletecontact.deleteEmergencyContacts();
		Assert.assertEquals(deletecontact.getcontactpage(), "Assigned Emergency Contacts");
	}
	@Test(priority=8)
	//before deleting data , we need to insert the manually in web site
	public void deleteEmergencyContact() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		deletedependency = new DeleteDependencyRelationInInfoPageTest(driver);
		deletedependency.deleteDependencypage();
		Assert.assertEquals(deletedependency.getpageChecked(),"Assigned Dependents");
		Assert.assertTrue(deletedependency.getmsgChecked().contains("Successfully Deleted"));
	}
	@Test(priority=6)
	public void addWorkExperienceDetails() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addworkexperiencepage = new AddWorkExperienceDetailsInInfoPageTest(driver);
		addworkexperiencepage.addWorkexperience();
		Assert.assertTrue(addworkexperiencepage.getcheckexperiencepage().contains("Add Work Experience"));
		addworkexperiencepage.setdetails("mina", "java developer","2012-03-02","2019-12-02");
	}
	@Test(priority=5)
	public void addpostinbuzzpage(){
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addpost = new AddPostInBuzzPageTest(driver);
		addpost.addPostBuzz("delevop app");
		Assert.assertEquals(addpost.getpostChecked(), "delevop app");
	}
	@Test(priority=4)
	public void addNationality() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addnation = new AddNationalityInAdminPageForCompanyTest(driver);
		addnation.setnationpage("italian");
		Assert.assertEquals(addnation.getcheckspanmsg(), "Already exists");
		addnation.setnationnameagain("Dutch");
		Assert.assertEquals(addnation.getlooknation(), "");
	}
	@Test(priority=3)
	public void addEmergencydetails() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addemergency = new AddEmergencyDetailsInInfoPageTest(driver);
		addemergency.addemergencydetails();
		Assert.assertEquals(addemergency.getcheckapge(),"Add Emergency Contact");
		addemergency.setdetails("sana", "wife","343434343","34343434","4343433");
	}
	@Test(priority=2)
	public void addDependencydetails() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		adddependency = new AddDependencyDetailsInInfoPageTest(driver);
		adddependency.adddepenedency();
		Assert.assertEquals(adddependency.getcheckpage(), "Add Dependent");
		adddependency.setdetails("mani", "other", "second_wife", "1978-03-02");
	}
	@Test(priority=1)
	public void addContactdetails() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addcontacts = new AddContactDetailsInInfoPageTest(driver);
		addcontacts.addcontats();
		Assert.assertEquals(addcontacts.getcheckpage(), "Contact Details");
		addcontacts.setDetails("gamiona", "mosia", "money", "43422442424", "343434344", "978377763", "alias@gmail.com", "devaisa@gmail.com");
	}
	@Test(priority=0)
	public void addCandidatedetails() {
		lpage =new LoginPage(driver);
		lpage.setloginDetails("Admin", "AdminUser@12345");
		addcandidatedetails =new AddCandidaeDetailsInRecruitmentPageTest(driver);
		addcandidatedetails.addcandidates();
		Assert.assertEquals(addcandidatedetails.getcheckapge(),"Add Candidate");
		addcandidatedetails.Adddetailstolist("mohan", "apkka", "famai", "mohan@gmail.com", "33283636237");
		Assert.assertEquals(addcandidatedetails.getmsgchecked(),"Successfully Saved");
	}
}	
