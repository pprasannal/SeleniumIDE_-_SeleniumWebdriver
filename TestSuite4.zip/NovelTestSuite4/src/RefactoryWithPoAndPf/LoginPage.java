package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	@FindBy(id="txtUsername")
	WebElement login;
	@FindBy(id="txtPassword")
	WebElement pswd;
	@FindBy(id="btnLogin")
	WebElement submit;
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setloginDetails(String username, String password) {
		login.sendKeys(username);
		pswd.sendKeys(password);
		submit.click();
	}
}
