package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddPostInBuzzPageTest {
	@FindBy(xpath="//b[contains(.,\'Buzz\')]")
	WebElement buzzpage;
	@FindBy(id="createPost_content")
	WebElement createpost;
	@FindBy(id="postSubmitBtn")
	WebElement addpost;
	@FindBy(xpath="//li/div/div[5]/div")
	WebElement checkpost;
	WebDriver driver;
	public AddPostInBuzzPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setAddpost(String postext) {
		buzzpage.click();
		createpost.sendKeys(postext);
		addpost.click();
	}
	public String getpostChecked() {
		return checkpost.getText();
	}
	public void addPostBuzz(String postext) {
		this.setAddpost(postext);
		this.getpostChecked();
	}
}
