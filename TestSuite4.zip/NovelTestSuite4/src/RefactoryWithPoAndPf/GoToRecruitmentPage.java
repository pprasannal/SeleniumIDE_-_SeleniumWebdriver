package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToRecruitmentPage {
	@FindBy(xpath="//a[@id='menu_recruitment_viewRecruitmentModule']/b")
	WebElement recuritmentbutton;
	WebDriver driver;
	public GoToRecruitmentPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void gotorecuritementpage() {
		recuritmentbutton.click();
	}
}
