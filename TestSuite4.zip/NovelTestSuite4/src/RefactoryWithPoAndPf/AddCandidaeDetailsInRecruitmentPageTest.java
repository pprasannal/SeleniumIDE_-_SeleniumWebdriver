package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCandidaeDetailsInRecruitmentPageTest {
	@FindBy(xpath="//b[contains(.,\'Recruitment\')]")
	WebElement recuritementpage;
	@FindBy(id="btnAdd")
	WebElement clickadd;
	@FindBy(id="addCandidateHeading")
	WebElement checkpage;
	@FindBy(id="addCandidate_firstName")
	WebElement firstname;
	@FindBy(id="addCandidate_middleName")
	WebElement middlename;
	@FindBy(id="addCandidate_lastName")
	WebElement lastname;
	@FindBy(id="addCandidate_email")
	WebElement email;
	@FindBy(id="addCandidate_contactNo")
	WebElement contactnnumber;
	@FindBy(id="addCandidate_consentToKeepData")
	WebElement keepdatabutton;
	@FindBy(id="btnSave")
	WebElement savedetails;
	@FindBy(xpath="//body/div/div[3]/div/div[2]/div")
	WebElement verifymsg;
	WebDriver driver;
	public AddCandidaeDetailsInRecruitmentPageTest(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void settocandidate() {
		recuritementpage.click();
		clickadd.click();
	}
	public String getcheckapge() {
		return checkpage.getText();
	}
	public void setdetails(String name1, String name2, String name3, String emailid, String number) {
		firstname.sendKeys(name1);
		middlename.sendKeys(name2);
		lastname.sendKeys(name3);
		email.sendKeys(emailid);
		contactnnumber.sendKeys(number);
		keepdatabutton.click();
		savedetails.click();
	}
	public String getmsgchecked() {
		return verifymsg.getText();
	}
	public void addcandidates() {
		this.settocandidate();
		this.getcheckapge();
	}
	public void Adddetailstolist(String name1, String name2, String name3, String emailid, String number ) {
		this.setdetails(name1, name2, name3, emailid, number);
		this.getmsgchecked();
	}
}
