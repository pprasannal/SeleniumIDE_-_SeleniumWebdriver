package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoToQualificationPage {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement myinfobutton;
	@FindBy(xpath="//a[contains(@href, '/orangehrm/orangehrm-4.4/symfony/web/index.php/pim/viewQualifications/empNumber/1')]")
	WebElement qualififcationbutton;
	@FindBy(xpath="//div[3]/div/h1")
	WebElement workexperience;
	@FindBy(xpath="//div[5]/div/h1")
	WebElement education;
	@FindBy(xpath="//div[@id='tblSkill']/div/h1")
	WebElement skills;
	@FindBy(xpath="//div[@id='tblLanguage']/div/h1")
	WebElement language;
	@FindBy(xpath="//div[11]/div/h1")
	WebElement license;
	
	WebDriver driver;
	public GoToQualificationPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void gotoqualififcation() {
		myinfobutton.click();
		qualififcationbutton.click();
	}
	public String getqualificationChecked() {
		return workexperience.getText();
	}
	public String getEducationchecked() {
		return education.getText();
	}
	public String getLanguage() {
		return language.getText();
	}
	public Boolean checkwait(String Licesnce) {
		WebDriverWait wait = new WebDriverWait(driver, 0);
	      wait.until(ExpectedConditions.visibilityOf(skills));
	      return wait.until(ExpectedConditions.textToBePresentInElement(license,Licesnce));
	}
	public void gotoQualificationPage(String Licesnce) {
		this.gotoqualififcation();
		this.getqualificationChecked();
		this.getEducationchecked();
		this.checkwait(Licesnce);
		this.getLanguage();
		
	}
}
