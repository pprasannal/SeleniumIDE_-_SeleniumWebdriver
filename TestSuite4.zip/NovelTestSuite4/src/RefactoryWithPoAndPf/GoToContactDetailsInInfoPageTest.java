package RefactoryWithPoAndPf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToContactDetailsInInfoPageTest {
	@FindBy(xpath="//b[contains(.,'My Info')]")
	WebElement infopage;
	@FindBy(xpath="//a[contains(@href, '/orangehrm/orangehrm-4.4/symfony/web/index.php/pim/contactDetails/empNumber/1')]")
	WebElement conctactpage;
	@FindBy(xpath="//h1[contains(.,'Contact Details')]")
	WebElement checkcontactpage;
	WebDriver driver;
	public GoToContactDetailsInInfoPageTest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setcontactpage() {
		infopage.click();
		conctactpage.click();
	}
	public String getcontactpage() {
		return checkcontactpage.getText();
	}
	public void gotocontactdetails() {
		this.setcontactpage();
		this.getcontactpage();
	}
}
