package withPOs_PageFactory ;

import org.testng.Assert;

import org.testng.annotations.Test;

class TestScript extends SeleniumIDESetup {

	HomePage hpage;
	LoginPage lpage;
	AdminUserPage adminuser; 
	AddNewUserInformation adduser;
	GoToEmployeePage employeepage;
	DupliacteClassForClickButton dupliacte;
	
	
	@Test(priority=0)
	void testInvalidPassword() {
		lpage = new LoginPage(driver);
		Assert.assertEquals(lpage.getTitlepage(),"LOGIN Panel");
		lpage.loginToOrangeHRMForInvalidPswd("Admin","AdminUser@123");
		System.out.println(lpage.getclickLoginForInvalidPswd());
		Assert.assertTrue(lpage.getclickLoginForInvalidPswd().contains("Username cannot be empty"));
		
	}
	@Test(priority=1)
	void testLogin() {
		lpage = new LoginPage(driver); 
		Assert.assertEquals(lpage.getTitlepage(),"LOGIN Panel");
		//lpage.loginToOrangeHRM("Admin", "AdminUser@12345");
		//hpage =new HomePage(driver);	
		hpage=lpage.loginToOrangeHRM("Admin","AdminUser@12345");
		Assert.assertTrue(hpage.getHomePage().contains("Dashboard"));
	}
	@Test(priority=2)
	void testHomePage() {
		lpage = new LoginPage(driver);
		hpage=lpage.loginToOrangeHRM("Admin","AdminUser@12345");
		Assert.assertTrue(hpage.getHomePage().contains("Dashboard"));
		adminuser = new AdminUserPage(driver);
		adminuser.adminUserPage();
		
	} 
	@Test(priority=3)
	void gotoemployeePage() {
		lpage = new LoginPage(driver);
		hpage=lpage.loginToOrangeHRM("Admin","AdminUser@12345");
		employeepage = new GoToEmployeePage(driver); 
		employeepage.employeePage();
		dupliacte = new DupliacteClassForClickButton(driver);
		//dupliacte=employeepage.clickaddEmployee();
		//dupliacte.clickAction();
		
	}
	@Test(priority=4)
	void testGoToAddNewUserPage() {
		lpage = new LoginPage(driver);
		adminuser = new AdminUserPage(driver);
		hpage=lpage.loginToOrangeHRM("Admin","AdminUser@12345");
		Assert.assertTrue(hpage.getHomePage().contains("Dashboard"));
		adduser=adminuser.adminUserPage();
		System.out.println(adduser.getadduser());
		Assert.assertTrue(adduser.getadduser().contains("Add User"));
	}
	@Test(priority=5)
	void  testAddNewUserDetails() {
		lpage = new LoginPage(driver);
		adminuser = new AdminUserPage(driver);
		hpage=lpage.loginToOrangeHRM("Admin","AdminUser@12345");
		Assert.assertTrue(hpage.getHomePage().contains("Dashboard"));
		adduser=adminuser.adminUserPage();
		System.out.println(adduser.getadduser());
		Assert.assertTrue(adduser.getadduser().contains("Add User"));
		adduser.AddNewUserDetailsForEmployee("srinvas rao paru","srininvas" ,"SrinivasRao@12345","SrinivasRao@12345");
	}
}
