package withPOs_PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GoToEmployeePage {
	@FindBy(xpath="//b[contains(text(),'PIM')]")
	WebElement pim;
	@FindBy(xpath="//div[@id='search-results']//input[@id='btnAdd']")
	//@FindBy(xpath="/html[1]/body[1]/div[1]/div[3]/div[2]/div[1]/div[1]/form[1]/div[1]/input[1]")
	WebElement addemployee;
	WebDriver driver;	
	public GoToEmployeePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void pimemployee(){
		pim.click();
	}
	public void employeePage() {
		this.pimemployee();
		this.clickaddEmployee();
	}
	public DupliacteClassForClickButton clickaddEmployee() {
		//addemployee.click();
		return new DupliacteClassForClickButton(driver);
		
	}
}
