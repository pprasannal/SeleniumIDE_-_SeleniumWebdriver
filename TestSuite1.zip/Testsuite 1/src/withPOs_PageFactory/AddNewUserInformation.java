package withPOs_PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddNewUserInformation {
	WebDriver driver;
	@FindBy(id="UserHeading")
	WebElement adduser;
	@FindBy(id="systemUser_employeeName_empName")
	WebElement employeename;
	@FindBy(id="systemUser_userName")
	WebElement username;
	@FindBy(id="systemUser_password")
	WebElement password;
	@FindBy(id="systemUser_confirmPassword")
	WebElement confirmpswd;
	@FindBy(name="btnSave")
	WebElement saveEmployeeDetails;
	public AddNewUserInformation(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public String getadduser() {
		return adduser.getText();
	}
	public void setemployeename(String NameofEmployee) {
		employeename.sendKeys(NameofEmployee);
	}
	public void setUsername(String addusername) {
		username.sendKeys(addusername);
	}
	public void setPaswword(String addpswd) {
		password.sendKeys(addpswd);
	}
	public void setConfirmPswd(String addConfirmpswd) {
		confirmpswd.sendKeys(addConfirmpswd);
	}
	public void saveUserDetails() {
		saveEmployeeDetails.click();
	}
	public void AddNewUserDetailsForEmployee(String NameofEmployee,String addusername, String addpswd,String addConfirmpswd) {
		this.setemployeename(NameofEmployee);
		this.setUsername(addusername);
		this.setPaswword(addpswd);
		this.setConfirmPswd(addConfirmpswd);
		this.saveUserDetails();
	}
}
