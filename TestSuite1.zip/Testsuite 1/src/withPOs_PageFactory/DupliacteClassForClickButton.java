package withPOs_PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DupliacteClassForClickButton {
	WebDriver driver;
	@FindBy(id="btnAdd")
	WebElement clickButton;
	public DupliacteClassForClickButton(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		clickAction();
	}
	public void clickAction() {
		System.out.println(clickButton.getText());
		clickButton.click();
	}
}
