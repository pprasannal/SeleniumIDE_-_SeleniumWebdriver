package withPOs_PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminUserPage {
	WebDriver driver;
	@FindBy(xpath="//b[contains(text(),'Admin')]")
	WebElement admin;
	@FindBy(id="btnAdd")
	WebElement adduser;
	public AdminUserPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void adminUser(){
		admin.click();
	}
	public AddNewUserInformation adminUserPage() {
		this.adminUser();
		this.clickaddUser();
		return new AddNewUserInformation(driver);
	}
	public void clickaddUser() {
		adduser.click();
		
	}
}
